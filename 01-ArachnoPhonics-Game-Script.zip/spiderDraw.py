import os
#spider0
def spider_0():
  print(f"""
        - - - - - - - -
        
        
        




        
        """)

#spider1
def spider_1():
  print(f"""
        - - - - - - - -
               |       
               |       
               |       
        
        


        
        """)

  #spider2
def spider_2():
  print(f"""
        - - - - - - - -
               |       
               |       
               |  
              ___ 
             /   \ 
             \___/   
              ( )      

        """)


  #spider3
def spider_3():
  print(f"""
        - - - - - - - -
               |       
               |       
               |  
              ___ 
             /   \ 
             \___/   
             /( )\   
             \   /
        """)
 
  #spider4
def spider_4():
  print(f"""
        - - - - - - - -
               |       
               |       
               |  
              ___ 
             /   \ 
         \__ \___/ __/   
             /( )\   
             \   /
        """)

  
  #spider5
def spider_5():
  print(f"""
        - - - - - - - -
               |       
               |       
               |  
              ___ 
             /   \ 
         \__ \___/ __/   
          _/ /( )\ \_  
             \   /
        """)
  

  #spider6
def spider_6():
  print(f"""
        - - - - - - - -
               |       
               |       
               |  
              ___   
          \_ /   \ _/
         \__ \___/ __/   
          _/ /(0)\ \_  
             \   /
        """)

  