#access libraries and py files
import os
import time
import spiderDraw as sd
import functions as md

#Initialize variables and setup
#Need to keep track of correct letters, incorrect letters and tries
correct = []
incorrect = []
tries = 0
game = True
wins = 0
losses = 0
#Make a list of the spider drawings
spiderList = [sd.spider_0, sd.spider_1, sd.spider_2, sd.spider_3, sd.spider_4, sd.spider_5, sd.spider_6]

#Print intro statements (welcome to game, etc)
md.introduction()
#generate a random word from word list
word = md.generate_word()
#Game Loop

while game:
  tries = md.check_word(correct, incorrect, word, tries)
  os.system('clear')
  time.sleep(1)
  md.print_spider(tries, spiderList)
  progress = md.print_word(word, correct)
  print(f'You have guessed incorrectly {tries} times')
  if progress == word:
    print('You did it, You won! ')
    wins += 1
    print(f'You have {wins} wins and {losses} losses.')
    answer = input('Would you like to play again, yes or no? ')
    if answer == 'no':
      game = False
    elif answer == 'yes':
      word = md.generate_word()
      incorrect.clear()
      correct.clear()
      tries = 0
  elif tries > 5:
    print('So sorry, you lost, try again. ')
    losses += 1
    print(f'You have {wins} wins and {losses} losses.')
    answer = input('Would you like to play again, yes or no? ')
    if answer == 'no':
      game = False
    elif answer == 'yes':
      word = md.generate_word()
      incorrect.clear()
      correct.clear()
      tries = 0


  
    
    

    #This is where you'll call all of your functions. Just need to decide the proper order.

    #You will also need to specify your win and lose conditions in here
